import React from "react";
// import { useNavigate } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import '../styles/common.css';

export const Header = () => {

const history = createBrowserHistory();
// const navigate = useNavigate();

    return(
        <div className="HeaderContainerDiv">
            <div onClick={history.push('/home')}>Home</div>
            <div onClick={history.push('/addemplist')}>Add Emplyee</div>
            <div onClick={history.push('/emplist')}>View List Of Employees</div>
        </div>
    )
}