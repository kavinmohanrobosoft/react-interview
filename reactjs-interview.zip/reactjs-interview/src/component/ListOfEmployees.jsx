import React, { Fragment } from "react";
import { Header } from "../common/Header";

export const ListOfEmployees = () => {
  return (
    <Fragment>
      <Header />
      <div>
        <div>First Name: </div>
        <div>Last Name: </div>
        <div>Dob: </div>
        <div>Designation: </div>
        <div>Image: </div>
        <div>Experience: </div>
      </div>
    </Fragment>
  );
};
