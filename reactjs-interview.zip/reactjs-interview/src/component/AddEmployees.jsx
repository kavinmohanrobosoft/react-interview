import React, { Fragment, useState } from "react";

import { Header } from "../common/Header";

import '../styles/common.css';

const AddEmployeeList = () => {
  const [empList, setEmpList] = useState([]);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [dob, setdob] = useState("");
  const [designation, setDesignation] = useState("");
  const [image, setImage] = useState("");
  const [experience, setExperience] = useState("");

console.log("empList", empList)

  return (
    <Fragment>
      <Header />
    <form
      onSubmit={() => setEmpList([...empList, {
        Fname: firstName,
        lName: lastName,
        DOB: dob,
        Designation: designation,
        imgLink: image,
        Exp: experience,
      }])}
    >
      <div className="addListDiv">
      <input
        type="text"
        onChange={(e) => setFirstName(e.target.value)}
        value={firstName}
        placeholder="First Name"
      />
      <input
        type="text"
        onChange={(e) => setLastName(e.target.value)}
        value={lastName}
        placeholder="Last Name"
      />
      <input type="text" onChange={(e) => setdob(e.target.value)} value={dob} placeholder="DOB" />
      <input
        type="text"
        onChange={(e) => setDesignation(e.target.value)}
        value={designation}
        placeholder="Designation"
      />
      <input
        type="text"
        onChange={(e) => setImage(e.target.value)}
        value={image}
        placeholder="Image Link"
      />
      <input
        type="text"
        onChange={(e) => setExperience(e.target.value)}
        value={experience}
        placeholder="Experience"
      />
      <button>Submit</button>
      </div>
    </form>
    </Fragment>
  );
};

export default AddEmployeeList;
