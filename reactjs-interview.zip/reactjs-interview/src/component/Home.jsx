import React, { Component, Fragment } from "react";

import { Header } from "../common/Header";

class Home extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Fragment>
        <Header />

        <h2 className="text-center">Home</h2>
      </Fragment>
    );
  }
}

export default Home;
