import React, { createContext } from "react";

const EmployeesList =  createContext();

const AddEmploee = (value) => {
return (
    <EmployeesList.Provider value={value}>
        
    </EmployeesList.Provider>
)
}